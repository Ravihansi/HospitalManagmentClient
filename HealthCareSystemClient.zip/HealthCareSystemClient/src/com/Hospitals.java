package com;

import java.sql.*;

public class Hospitals {


public class Item {

	private Connection connect(){
		
	Connection con = null;
			try
				{
				Class.forName("com.mysql.jdbc.Driver");
				//Provide the correct details: DBServer/DBName, username, password
				con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/test","root","");
				}
			catch (Exception e){
				e.printStackTrace();
			}
	return con;
	
	}
	
	//insert-----------------------------------------------------------------------------------------------------------------------------
	
	public String insertHospitals(String hospitalName, String doctorID, String treatmentID)
    {
			String output = "";
			try
			{
				Connection con = connect();
				if (con == null)
				{    
					return "Error while connecting to the database for inserting.";
				}
				// create a prepared statement
				String query = "insert into hospitals"
						+"(`hospitalID`,`hospitalName`,`doctorID`,`treatmentID`)"
						 + " values (?, ?, ?, ?)";
						PreparedStatement preparedStmt = con.prepareStatement(query); 
				// binding values
				preparedStmt.setInt(1, 0);
				preparedStmt.setString(2, hospitalName);
				preparedStmt.setString(3, doctorID);
				preparedStmt.setString(4, treatmentID); 
	
				// execute the statement
				preparedStmt.execute();
				con.close();
				
				String newHospital = readHospitals();
				output = "{\"status\":\"success\", \"data\": \"" +newHospital + "\"}";
			}
				catch (Exception e)
			{
					output = "{\"status\":\"error\", \"data\": \"Error while inserting the hospital.\"}";
					System.err.println(e.getMessage());
			}
			return output;
    		}
	
	
	//view------------------------------------------------------------------------------------------------------------------------
	public String readHospitals(){
		
		String output = "";
			try{
			Connection con = connect();
			
			if (con == null){
				return "Error while connecting to the database for reading."; 
			}
			// Prepare the html table to be displayed
			output = "<table border='1'>"
					+ "<th>Hospital Name</th>"
					+ "<th>Doctor ID</th>"
					+ "<th>Treatment ID</th>"
					+ "<th>Update</th>"
					+ "<th>Remove</th></tr>";
			
			String query = "select * from hospitals";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			// iterate through the rows in the result set
			while (rs.next()){
				
				String hospitalID = Integer.toString(rs.getInt("Hospital ID"));
				String hospitalName = rs.getString("hospitalName");
				String doctorID = rs.getString("doctorID");
				String treatmentID = rs.getString("treatmentID");

				
				// Add into the html table
				output += "<tr><td><input id='hidHospitalIDUpdate'name='hidHospitalIDUpdate' type='hidden' value='" + hospitalID+ "'>" + hospitalName + "</td>";
				output += "<td>" + hospitalName + "</td>";
				output += "<td>" + doctorID + "</td>";
				output += "<td>" + treatmentID + "</td>";
				 // buttons
				
				output += "<td><input name='btnUpdate'type='button' "
						+ "value='Update'class='btnUpdate btn btn-secondary'></td>"
						+ "<td><input name='btnRemove'type='button' "
						+ "value='Remove'class='btnRemove btn btn-danger'data-itemid='"+ hospitalID + "'>" + "</td></tr>";
			}
			
			con.close();
			// Complete the html table
			output += "</table>";
			}
			catch (Exception e){
				output = "Error while reading the items.";
				System.err.println(e.getMessage());
			}
			
	return output;
	
	}
	
	
	//update----------------------------------------------------------------------------------------------------------------
	public String updateHospitala(String hospitalID, String hospitalName, String doctorID, String treatmentID) {
		String output = "";
		try {
			Connection con = connect();
			if (con == null) {
				return "Error while connecting to the database for updating.";
			}
			// create a prepared statement
			String query = "UPDATE hospitals SET hospitalName=?,doctorID=?,treatmentID=?";
			PreparedStatement preparedStmt = con.prepareStatement(query);
			// binding values
			preparedStmt.setString(1, hospitalName);
			preparedStmt.setString(2, doctorID);
			preparedStmt.setString(3, treatmentID);
			preparedStmt.setInt(4, Integer.parseInt(hospitalID));
			// execute the statement
			preparedStmt.execute();
			con.close();
			
			String newHospitals = readHospitals();
			output = "{\"status\":\"success\", \"data\": \"" + newHospitals + "\"}";;
		} catch (Exception e) {
			output = "{\"status\":\"error\", \"data\": \"Error while updating the hospital.\"}";
			System.err.println(e.getMessage());
		}
		return output;
	}

	
	//delete-------------------------------------------------------------------------------------------------------------------
	public String deleteHospitals(String hospitalID) {
		String output = "";
		try {
			Connection con = connect();
			if (con == null) {

				return "Error while connecting to the database for deleting.";
			}
			// create a prepared statement
			String query = "delete from hospitals where hospitalID=?";
			PreparedStatement preparedStmt = con.prepareStatement(query);
			// binding values
			preparedStmt.setInt(1, Integer.parseInt(hospitalID));
			// execute the statement
			preparedStmt.execute();
			con.close();
			
			String newHospitals = readHospitals();
			output = "{\"status\":\"success\", \"data\": \"" + newHospitals + "\"}";
		} catch (Exception e) {
			output = "{\"status\":\"error\", \"data\": \"Error while deleting the hospital.\"}";
			System.err.println(e.getMessage());
		}
		return output;
	}
	
}
}
